CivEconomy coin resource pack for Minecraft Java 1.21.11.
Upload this ZIP directly as the server resource pack.
Do not upload the containing folder.
